const botao = document.getElementById('botao-carregar');
const lista = document.getElementById('lista-pokemons');

async function buscarPokemons() {
    try {
        // Limpa a lista antes de carregar novos (opcional, mas bom para UX)
        lista.innerHTML = '<p>Carregando...</p>';
        
        const resposta = await fetch('https://pokeapi.co/api/v2/pokemon?limit=10');
        
        if (!resposta.ok) {
            throw new Error('Falha na requisição');
        }

        const dados = await resposta.json();
        console.log(dados.results);

        // Limpa a mensagem de carregando
        lista.innerHTML = '';

        for (const pokemon of dados.results) {
            console.log(pokemon.name);
            
            // Busca os detalhes de cada Pokémon
            const respostaDetalhes = await fetch(pokemon.url);
            const detalhes = await respostaDetalhes.json();

            // Cria o elemento do card
            const card = document.createElement('div');
            card.classList.add('card');
            
            card.innerHTML = `
                <img src="${detalhes.sprites.other['official-artwork'].front_default}" alt="${detalhes.name}">
                <h2>${detalhes.name}</h2>
            `;
            
            lista.appendChild(card);
        }
    } catch (erro) {
        console.error('Erro ao carregar Pokémon:', erro);
        lista.innerHTML = '<p class="erro">Erro ao carregar Pokémon. Verifique sua conexão.</p>';
    }
}

botao.addEventListener('click', buscarPokemons);
